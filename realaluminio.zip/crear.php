<html>
     header('location') ;
    <body>
      
        <?php
        $boton= $_POST["next"];
        if($boton == "next")
        {

        }
        ?>
    </body>
</html>