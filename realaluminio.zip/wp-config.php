<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'id17297469_wp_5bd048b1d88d8a58c7a321438e78b388' );

/** MySQL database username */
define( 'DB_USER', 'id17297469_wp_5bd048b1d88d8a58c7a321438e78b388' );

/** MySQL database password */
define( 'DB_PASSWORD', 'd1a6c212f3a7cb7add2d5463e9900790ce0628b2' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ' `xe?$=P!~Wv;AF|JWotgkix@&&%(f}0rnbGb.HG3 (6&hnr>%l,^-8]XOLhP$pw' );
define( 'SECURE_AUTH_KEY',   '00/vF4PlKK0)9yQ}n4%tvXohe~A1[|]Tb2zuL@eiqYL@6=<Qb5Jnrq_kznU!H*@n' );
define( 'LOGGED_IN_KEY',     '_&kdl1*YN!x+tD~dKv59}Ra7)f*Eu%7[Hf3-*H$>O{,Arwu@gieIHF<HELQMm6H)' );
define( 'NONCE_KEY',         '&%[g1IYllSj,r%.spm`OruTQ3J-V91z_pLDRk76@Q3n@xj=q$nu)u!]EVJ!U)>b)' );
define( 'AUTH_SALT',         'ZCjdmpAZFrhZVMG]P81m>PvwPWg~J=sm!H>Der2S+0J3_[PwJ.Lo^FEhiht!z2S{' );
define( 'SECURE_AUTH_SALT',  'P_ []7fYinuSeuC9T@V n1Wx6#K0:=hEQ@~,`laxO3kDLe?pME%`dX=.u:#|q~jO' );
define( 'LOGGED_IN_SALT',    'df~|OFG?pLzKYZpXi0T0)NB>(L$IO!D^lHzF6|M64r]pa3qLF/$Sw&::;nK3rex[' );
define( 'NONCE_SALT',        '`j]i@j@$I_v)oUi:y)&.,kXg%.s#h7bfRQ}bj@}%d&SN~xlm4[`!Gf7h`u;;uQ!=' );
define( 'WP_CACHE_KEY_SALT', '$B4+ HgAVWQ,c|c[,_7CA vARNTv@jZ,PgFuSjT42/:V<]I/GhF:Z5Bfbr|T;)g;' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
